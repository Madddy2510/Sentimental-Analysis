We have tried to extract tweets from twitter and perform sentiment and temporal analysis on them.
